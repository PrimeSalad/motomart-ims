/*
 * Carbon & Crimson IMS
 * File: src/views/login_page.jsx
 * Version: 1.1.0
 * Purpose: Login screen with solid UX (validation, show/hide password, forgot password modal).
 * Notes:
 * - Fixes blank/black screen by returning complete JSX.
 * - Forgot password calls backend and sends a secure reset link via email.
 */

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Lock, Mail, LogIn, Eye, EyeOff, ShieldAlert, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createApiClient } from '../lib/api_client';
import { useAuth } from '../state/auth_context';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function LoginPage() {
  const { setAuth, token } = useAuth();
  const navigate = useNavigate();
  const api = useMemo(() => createApiClient({ token: null }), []);

  const [email, setEmail] = useState('admin@ims.local');
  const [password, setPassword] = useState('Admin#1234');
  const [remember, setRemember] = useState(true);

  const [error, setError] = useState(null);
  const [capsLockOn, setCapsLockOn] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('admin@ims.local');
  const [forgotSent, setForgotSent] = useState(false);

  const emailRef = useRef(null);

  // If already logged in, bounce to dashboard
  useEffect(() => {
    if (token) navigate('/', { replace: true });
  }, [token, navigate]);

  useEffect(() => {
    // Focus on first field for keyboard-first UX
    emailRef.current?.focus?.();
  }, []);

  const validate = () => {
    if (!email || !EMAIL_RE.test(email)) return 'Please enter a valid email.';
    if (!password || password.length < 6) return 'Password must be at least 6 characters.';
    return null;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    const v = validate();
    if (v) {
      setError(v);
      return;
    }

    setLoading(true);
    try {
      const res = await api.post('/auth/login', { email, password });

      // Save token/user
      setAuth(res.data.data, { remember });

      // Redirect
      navigate('/', { replace: true });
    } catch (err) {
      const msg = err?.response?.data?.error?.message || err?.message || 'Login failed.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const onPasswordKey = (e) => {
    // CapsLock hint (best-effort)
    const caps = e.getModifierState ? e.getModifierState('CapsLock') : false;
    setCapsLockOn(Boolean(caps));
  };

  const openForgot = () => {
    setForgotSent(false);
    setForgotEmail(email || 'admin@ims.local');
    setForgotOpen(true);
  };

  const submitForgot = async (e) => {
    e.preventDefault();
    setForgotSent(false);
    setError(null);

    if (!forgotEmail || !EMAIL_RE.test(forgotEmail)) {
      setForgotSent(false);
      return;
    }

    try {
      await api.post('/auth/forgot-password', { email: forgotEmail });
      // Always show success to prevent account enumeration
      setForgotSent(true);
    } catch (err) {
      const msg = err?.response?.data?.error?.message || err?.message || 'Request failed.';
      setError(msg);
      setForgotSent(false);
    }
  };

  const closeForgot = () => setForgotOpen(false);

  return (
    <div className="min-h-screen w-full bg-[#06060a] text-white relative overflow-hidden">
      {/* Ambient backdrop */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-40 -left-40 h-[420px] w-[420px] rounded-full bg-red-500/20 blur-3xl" />
        <div className="absolute -bottom-40 -right-40 h-[520px] w-[520px] rounded-full bg-rose-500/15 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,255,255,0.05),transparent_55%)]" />
        <div className="absolute inset-0 opacity-50 [background-image:linear-gradient(to_right,rgba(255,255,255,0.04)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.04)_1px,transparent_1px)] [background-size:48px_48px]" />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-[1200px] items-center justify-center px-4 py-10">
        <div className="grid w-full grid-cols-1 gap-8 lg:grid-cols-2">
          {/* Left: Brand / copy */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45 }}
            className="hidden lg:flex flex-col justify-center"
          >
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-[11px] font-bold tracking-[0.22em] uppercase text-white/70 w-fit">
              Motomart
            </div>

            <h1 className="mt-5 text-4xl font-black tracking-tight leading-[1.1]">
              Inventory made <span className="text-red-400">clean</span>, fast, and reliable.
            </h1>

            <p className="mt-4 max-w-[44ch] text-white/70 leading-relaxed">
              Sign in to manage stock, monitor movement, and keep operations smooth—without the clutter.
            </p>

            <div className="mt-8 grid grid-cols-2 gap-4 max-w-[520px]">
              {[
                { title: 'Protected access', desc: 'Token-based session handling' },
                { title: 'Fast UI', desc: 'Snappy screens with modern UX' },
                { title: 'Audit-friendly', desc: 'Clear data visibility' },
                { title: 'Responsive', desc: 'Works well on mobile and desktop' }
              ].map((b) => (
                <div
                  key={b.title}
                  className="rounded-2xl border border-white/10 bg-white/[0.02] p-4 shadow-[0_10px_40px_rgba(0,0,0,0.35)]"
                >
                  <div className="text-sm font-bold">{b.title}</div>
                  <div className="mt-1 text-xs text-white/60">{b.desc}</div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right: Form */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.06 }}
            className="flex items-center justify-center"
          >
            <div className="w-full max-w-md rounded-[28px] border border-white/10 bg-white/[0.03] p-6 sm:p-8 backdrop-blur-xl shadow-[0_18px_60px_rgba(0,0,0,0.55)]">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-2xl font-black tracking-tight">Welcome back</div>
                  <div className="mt-1 text-sm text-white/60">Sign in to continue.</div>
                </div>
                <div className="h-11 w-11 rounded-2xl border border-white/10 bg-white/[0.02] grid place-items-center">
                  <LogIn className="h-5 w-5 text-red-300" />
                </div>
              </div>

              {error ? (
                <div
                  role="alert"
                  className="mt-5 flex items-start gap-3 rounded-2xl border border-red-500/30 bg-red-500/10 p-4 text-sm"
                >
                  <ShieldAlert className="h-5 w-5 text-red-300 mt-0.5" />
                  <div className="text-white/80">{error}</div>
                </div>
              ) : null}

              <form onSubmit={onSubmit} className="mt-6 space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-[0.18em] text-white/60" htmlFor="email">
                    Email
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35" />
                    <input
                      ref={emailRef}
                      id="email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full rounded-2xl border border-white/10 bg-white/[0.02] px-12 py-3 text-sm outline-none transition focus:border-white/20 focus:bg-white/[0.03]"
                      placeholder="you@company.com"
                      aria-label="Email"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-[0.18em] text-white/60" htmlFor="password">
                    Password
                  </label>

                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35" />
                    <input
                      id="password"
                      name="password"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      onKeyUp={onPasswordKey}
                      className="w-full rounded-2xl border border-white/10 bg-white/[0.02] px-12 pr-12 py-3 text-sm outline-none transition focus:border-white/20 focus:bg-white/[0.03]"
                      placeholder="••••••••"
                      aria-label="Password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((v) => !v)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 rounded-xl border border-white/10 bg-white/[0.02] px-3 py-2 text-xs text-white/70 hover:bg-white/[0.05] transition"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>

                  {capsLockOn ? (
                    <div className="text-[12px] text-amber-200/80">Caps Lock is on.</div>
                  ) : null}
                </div>

                <div className="flex items-center justify-between gap-4">
                  <label className="flex items-center gap-2 text-sm text-white/70 select-none">
                    <input
                      type="checkbox"
                      checked={remember}
                      onChange={(e) => setRemember(e.target.checked)}
                      className="h-4 w-4 rounded border-white/20 bg-white/10"
                    />
                    Remember me
                  </label>

                  <button
                    type="button"
                    onClick={openForgot}
                    className="text-sm font-semibold text-red-300 hover:text-red-200 transition"
                  >
                    Forgot password?
                  </button>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="group mt-2 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-red-500 to-rose-500 px-4 py-3 text-sm font-black tracking-wide text-black shadow-[0_18px_40px_rgba(244,63,94,0.25)] transition hover:brightness-110 disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <>
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-black/30 border-t-black" />
                      Signing in…
                    </>
                  ) : (
                    <>
                      <LogIn className="h-4 w-4" />
                      Sign in
                    </>
                  )}
                </button>

                <div className="pt-2 text-xs text-white/55 leading-relaxed">
                  Tip: default demo account is <span className="font-semibold text-white/70">admin@ims.local</span>
                </div>
              </form>

              <div className="mt-6 border-t border-white/10 pt-4 text-xs text-white/50">
                Having trouble? Make sure the backend is running and your <code className="text-white/70">VITE_API_BASE_URL</code> is correct.
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Forgot password modal */}
      {forgotOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={closeForgot} />
          <motion.div
            initial={{ opacity: 0, y: 12, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.18 }}
            className="relative z-10 w-full max-w-md rounded-[26px] border border-white/10 bg-[#0b0b12] p-6 shadow-[0_30px_90px_rgba(0,0,0,0.7)]"
            role="dialog"
            aria-modal="true"
            aria-label="Forgot password"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-lg font-black">Reset password</div>
                <div className="mt-1 text-sm text-white/60">
                  Enter your email. We'll send a secure reset link.
                </div>
              </div>
              <button
                type="button"
                onClick={closeForgot}
                className="rounded-2xl border border-white/10 bg-white/[0.02] p-2 text-white/70 hover:bg-white/[0.05] transition"
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={submitForgot} className="mt-5 space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-[0.18em] text-white/60" htmlFor="forgot_email">
                  Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35" />
                  <input
                    id="forgot_email"
                    type="email"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    className="w-full rounded-2xl border border-white/10 bg-white/[0.02] px-12 py-3 text-sm outline-none transition focus:border-white/20 focus:bg-white/[0.03]"
                    placeholder="you@company.com"
                  />
                </div>
                {!forgotEmail || EMAIL_RE.test(forgotEmail) ? null : (
                  <div className="text-[12px] text-red-300/90">Please enter a valid email.</div>
                )}
              </div>

              <button
                type="submit"
                className="w-full rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm font-black text-white hover:bg-white/[0.06] transition"
              >
                Send reset link
              </button>

              {forgotSent ? (
                <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-4 text-sm text-white/75">
                  <div className="font-bold text-emerald-200">Email sent (if the account exists)</div>
                  <div className="mt-2 text-white/70">
                    Check your inbox for a password reset link. The link expires in 30 minutes.
                  </div>
                </div>
              ) : null}
            </form>
          </motion.div>
        </div>
      ) : null}
    </div>
  );
}

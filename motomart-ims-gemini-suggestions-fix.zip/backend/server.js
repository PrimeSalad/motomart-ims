/*
 * Carbon & Crimson IMS
 * File: server.js
 * Version: 1.0.0
 * Purpose: Express server entry point (Render/Docker ready).
 */

'use strict';

const http = require('http');
const app = require('./src/app');
const { connectMongo } = require('./src/config/db');
const { env } = require('./src/config/env');
const { seedDefaultUsers } = require('./src/seed/seed_users');
const { logger } = require('./src/utils/logger');

async function bootstrap() {
  await connectMongo(env.MONGO_URI);
  await seedDefaultUsers();

  const server = http.createServer(app);

  server.listen(env.PORT, () => {
    logger.info(`IMS API listening on :${env.PORT} (${env.NODE_ENV})`);
  });

  const shutdown = async (signal) => {
    logger.warn(`Received ${signal}. Shutting down...`);
    server.close(() => process.exit(0));
  };

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

bootstrap().catch((err) => {
  // eslint-disable-next-line no-console
  console.error(err);
  process.exit(1);
});

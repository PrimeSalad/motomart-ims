/*
 * Carbon & Crimson IMS
 * File: src/seed/seed_users.js
 * Version: 1.0.0
 * Purpose: Create default admin/staff users (idempotent).
 */

'use strict';

const { env } = require('../config/env');
const { User } = require('../models/user_model');
const { logger } = require('../utils/logger');

async function ensureUser({ email, name, role, password }) {
  const existing = await User.findOne({ email }).lean();
  if (existing) return;

  const password_hash = await User.hashPassword(password);
  await User.create({ email, name, role, password_hash });
}

async function seedDefaultUsers() {
  await ensureUser({
    email: env.SEED_ADMIN_EMAIL,
    name: 'Admin',
    role: 'admin',
    password: env.SEED_ADMIN_PASSWORD,
  });

  await ensureUser({
    email: env.SEED_STAFF_EMAIL,
    name: 'Staff',
    role: 'staff',
    password: env.SEED_STAFF_PASSWORD,
  });

  logger.info('Seed users ensured');
}

module.exports = { seedDefaultUsers };

/*
 * Carbon & Crimson IMS
 * File: src/services/gemini_service.js
 * Version: 2.0.0
 * Purpose: Gemini AI motorcycle parts suggestions (Gemini-only).
 *
 * Notes:
 * - Requires GEMINI_API_KEY in backend .env
 * - Returns a list of suggested parts (strings) for a bike query.
 */

'use strict';

const axios = require('axios');
const { env } = require('../config/env');

const GEMINI_URL =
  'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

function enabled() {
  return Boolean(env.GEMINI_API_KEY);
}

function extractText(resp) {
  const parts = resp?.data?.candidates?.[0]?.content?.parts;
  if (!Array.isArray(parts)) return '';
  return parts.map((p) => p.text).filter(Boolean).join('\n');
}

function safeJson(text) {
  try {
    return JSON.parse(text);
  } catch (_e) {
    return null;
  }
}

function pickJsonBlock(text) {
  const t = String(text || '').trim();
  const obj = t.match(/\{[\s\S]*\}/);
  if (obj) return obj[0];
  const arr = t.match(/\[[\s\S]*\]/);
  if (arr) return arr[0];
  return null;
}

async function suggestParts({ make, model, year }) {
  if (!enabled()) return [];

  const prompt = [
    'Return ONLY valid JSON. No markdown. No explanation.',
    '',
    'Bike:',
    `make: ${make || '(unknown)'}`,
    `model: ${model || '(unknown)'}`,
    `year: ${year || '(unknown)'}`,
    '',
    'JSON schema:',
    '{ "parts": [ { "name": string, "note": string|null } ] }',
    '',
    'Rules:',
    '- Max 12 parts.',
    '- Must be realistic motorcycle parts.',
    '- Use generic/common names that a mechanic would suggest.',
    '- If the bike details are incomplete, still provide reasonable common suggestions.',
  ].join('\n');

  const resp = await axios.post(
    `${GEMINI_URL}?key=${encodeURIComponent(env.GEMINI_API_KEY)}`,
    {
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.3, maxOutputTokens: 512 },
    },
    { timeout: 15000 }
  );

  const text = extractText(resp);
  const direct = safeJson(text);
  const parsed = direct || safeJson(pickJsonBlock(text) || '');

  const parts = Array.isArray(parsed?.parts) ? parsed.parts : [];
  return parts
    .map((p) => {
      if (typeof p === 'string') return { name: p, note: null };
      return { name: String(p?.name || '').trim(), note: p?.note == null ? null : String(p.note) };
    })
    .filter((p) => p.name)
    .slice(0, 12);
}

module.exports = { enabled, suggestParts };

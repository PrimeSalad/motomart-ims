/*
 * Carbon & Crimson IMS
 * File: src/app.js
 * Version: 1.0.0
 * Purpose: Express app wiring (middlewares, routes, error handler).
 */

'use strict';

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const { env } = require('./config/env');
const { notFoundHandler } = require('./middleware/not_found');
const { globalErrorHandler } = require('./middleware/global_error_handler');

const authRoutes = require('./routes/auth_routes');
const inventoryRoutes = require('./routes/inventory_routes');
const analyticsRoutes = require('./routes/analytics_routes');
const compatRoutes = require('./routes/compat_routes');

const app = express();

// Security & parsing
app.use(helmet());
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false }));

// Logs
app.use(morgan(env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// CORS
app.use(cors({
  origin: env.CORS_ORIGIN,
  credentials: true,
}));

// Rate limiting (mechanical, consistent, no spam)
app.use(rateLimit({
  windowMs: env.RATE_LIMIT_WINDOW_MS,
  max: env.RATE_LIMIT_MAX,
  standardHeaders: true,
  legacyHeaders: false,
}));

// Health
app.get('/api/health', (_req, res) => {
  res.status(200).json({ ok: true, service: 'carbon-crimson-ims-api', ts: new Date().toISOString() });
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/compat', compatRoutes);

// 404 + error handler
app.use(notFoundHandler);
app.use(globalErrorHandler);

module.exports = app;

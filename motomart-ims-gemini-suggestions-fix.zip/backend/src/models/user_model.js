/*
 * Carbon & Crimson IMS
 * File: src/models/user_model.js
 * Version: 1.0.0
 * Purpose: User model (RBAC: admin/staff).
 */

'use strict';

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  name: { type: String, required: true, trim: true },
  role: { type: String, required: true, enum: ['admin', 'staff'], default: 'staff' },
  password_hash: { type: String, required: true },
  password_changed_at: { type: Date },
  password_reset_token_hash: { type: String },
  password_reset_expires_at: { type: Date },
}, { timestamps: true });

userSchema.methods.verifyPassword = async function verifyPassword(plain) {
  return bcrypt.compare(plain, this.password_hash);
};

userSchema.methods.setPassword = async function setPassword(plain) {
  this.password_hash = await this.constructor.hashPassword(plain);
  this.password_changed_at = new Date();
  this.password_reset_token_hash = undefined;
  this.password_reset_expires_at = undefined;
};

userSchema.methods.createPasswordResetToken = function createPasswordResetToken() {
  // Token returned to user (email link). Store only the hash in DB.
  const raw = require('crypto').randomBytes(32).toString('hex');
  const hash = require('crypto').createHash('sha256').update(raw).digest('hex');

  this.password_reset_token_hash = hash;
  this.password_reset_expires_at = new Date(Date.now() + 1000 * 60 * 30); // 30 minutes

  return raw;
};

userSchema.statics.hashResetToken = function hashResetToken(raw) {
  return require('crypto').createHash('sha256').update(String(raw)).digest('hex');
};

userSchema.statics.hashPassword = async function hashPassword(plain) {
  const saltRounds = 12;
  return bcrypt.hash(plain, saltRounds);
};

const User = mongoose.model('User', userSchema);

module.exports = { User };

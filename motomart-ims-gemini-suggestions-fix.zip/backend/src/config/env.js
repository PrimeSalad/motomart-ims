/*
 * Carbon & Crimson IMS
 * File: src/config/env.js
 * Version: 1.0.0
 * Purpose: Centralized environment configuration with sane defaults.
 */

'use strict';

const dotenv = require('dotenv');
dotenv.config();

function readEnv(name, fallback = undefined) {
  const value = process.env[name];
  if (value === undefined || value === null || String(value).trim() === '') {
    return fallback;
  }
  return value;
}

const env = Object.freeze({
  NODE_ENV: readEnv('NODE_ENV', 'development'),
  PORT: Number(readEnv('PORT', '8080')),
  MONGO_URI: readEnv('MONGO_URI', 'mongodb://localhost:27017/ims_db'),

  JWT_SECRET: readEnv('JWT_SECRET', 'REPLACE_ME'),
  JWT_EXPIRES_IN: readEnv('JWT_EXPIRES_IN', '7d'),

  CORS_ORIGIN: readEnv('CORS_ORIGIN', 'http://localhost:5173'),

  API_NINJAS_KEY: readEnv('API_NINJAS_KEY', ''),
  GEMINI_API_KEY: readEnv('GEMINI_API_KEY', ''),

  APP_PUBLIC_URL: readEnv('APP_PUBLIC_URL', 'http://localhost:5173'),

  SMTP_HOST: readEnv('SMTP_HOST', ''),
  SMTP_PORT: Number(readEnv('SMTP_PORT', '587')),
  SMTP_SECURE: readEnv('SMTP_SECURE', 'false') === 'true',
  SMTP_USER: readEnv('SMTP_USER', ''),
  SMTP_PASS: readEnv('SMTP_PASS', ''),
  MAIL_FROM: readEnv('MAIL_FROM', ''),

  SEED_ADMIN_EMAIL: readEnv('SEED_ADMIN_EMAIL', 'admin@ims.local'),
  SEED_ADMIN_PASSWORD: readEnv('SEED_ADMIN_PASSWORD', 'Admin#1234'),
  SEED_STAFF_EMAIL: readEnv('SEED_STAFF_EMAIL', 'staff@ims.local'),
  SEED_STAFF_PASSWORD: readEnv('SEED_STAFF_PASSWORD', 'Staff#1234'),

  RATE_LIMIT_WINDOW_MS: Number(readEnv('RATE_LIMIT_WINDOW_MS', '60000')),
  RATE_LIMIT_MAX: Number(readEnv('RATE_LIMIT_MAX', '120')),
});

module.exports = { env };

/*
 * Carbon & Crimson IMS
 * File: src/routes/compat_routes.js
 * Version: 1.0.0
 * Purpose: Compatibility routes.
 */

'use strict';

const router = require('express').Router();
const { requireAuth } = require('../middleware/auth');
const { motorcycles } = require('../controllers/compat_controller');

router.use(requireAuth);
router.get('/motorcycles', motorcycles);

module.exports = router;

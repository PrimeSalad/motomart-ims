/*
 * Carbon & Crimson IMS
 * File: src/controllers/auth_controller.js
 * Version: 1.1.0
 * Purpose: Login endpoint (JWT).
 */

'use strict';

const { AppError } = require('../utils/app_error');
const { User } = require('../models/user_model');
const { signToken } = require('../services/jwt_service');
const { sendMail } = require('../services/mailer_service');
const { env } = require('../config/env');

async function login(req, res, next) {
  const { email, password } = req.body || {};

  if (!email || !password) {
    return next(new AppError('Email and password are required.', 400, 'VALIDATION_ERROR'));
  }

  const user = await User.findOne({ email: String(email).toLowerCase().trim() });
  if (!user) {
    return next(new AppError('Invalid credentials.', 401, 'UNAUTHORIZED'));
  }

  const ok = await user.verifyPassword(String(password));
  if (!ok) {
    return next(new AppError('Invalid credentials.', 401, 'UNAUTHORIZED'));
  }

  const token = signToken(String(user._id));

  return res.status(200).json({
    ok: true,
    data: {
      token,
      user: {
        id: String(user._id),
        email: user.email,
        name: user.name,
        role: user.role,
      },
    },
  });
}




async function changePassword(req, res, next) {
  const { current_password, new_password } = req.body || {};
  if (!current_password || !new_password) {
    return next(new AppError('Current password and new password are required.', 400, 'VALIDATION_ERROR'));
  }
  if (String(new_password).length < 8) {
    return next(new AppError('New password must be at least 8 characters.', 400, 'VALIDATION_ERROR'));
  }

  const user = await User.findById(req.user.id);
  if (!user) return next(new AppError('User not found.', 404, 'NOT_FOUND'));

  const ok = await user.verifyPassword(String(current_password));
  if (!ok) return next(new AppError('Current password is incorrect.', 401, 'UNAUTHORIZED'));

  await user.setPassword(String(new_password));
  await user.save();

  // Notify via email (best-effort)
  await sendMail({
    to: user.email,
    subject: 'Your MotoMart IMS password was changed',
    text: `Hello ${user.name || ''}\n\nYour password was changed successfully. If this wasn\'t you, contact your admin immediately.`,
  });

  return res.status(200).json({ ok: true });
}

async function forgotPassword(req, res, next) {
  const { email } = req.body || {};
  if (!email) return next(new AppError('Email is required.', 400, 'VALIDATION_ERROR'));

  const user = await User.findOne({ email: String(email).toLowerCase().trim() });
  // Always return OK to prevent account enumeration
  if (!user) {
    return res.status(200).json({ ok: true });
  }

  const token = user.createPasswordResetToken();
  await user.save();

  const resetUrl = `${env.APP_PUBLIC_URL}/reset-password?token=${encodeURIComponent(token)}`;

  await sendMail({
    to: user.email,
    subject: 'Reset your MotoMart IMS password',
    text: `Hello ${user.name || ''}\n\nYou requested a password reset.\n\nOpen this link to set a new password (valid for 30 minutes):\n${resetUrl}\n\nIf you did not request this, you can ignore this email.`,
    html: `<p>Hello ${user.name || ''}</p><p>You requested a password reset.</p><p><a href="${resetUrl}">Reset your password</a> (valid for 30 minutes).</p><p>If you did not request this, you can ignore this email.</p>`,
  });

  return res.status(200).json({ ok: true });
}

async function resetPassword(req, res, next) {
  const { token, new_password } = req.body || {};
  if (!token || !new_password) {
    return next(new AppError('Token and new password are required.', 400, 'VALIDATION_ERROR'));
  }
  if (String(new_password).length < 8) {
    return next(new AppError('New password must be at least 8 characters.', 400, 'VALIDATION_ERROR'));
  }

  const tokenHash = User.hashResetToken(token);
  const user = await User.findOne({
    password_reset_token_hash: tokenHash,
    password_reset_expires_at: { $gt: new Date() },
  });

  if (!user) {
    return next(new AppError('Invalid or expired reset token.', 400, 'INVALID_TOKEN'));
  }

  await user.setPassword(String(new_password));
  await user.save();

  await sendMail({
    to: user.email,
    subject: 'Your MotoMart IMS password was reset',
    text: `Hello ${user.name || ''}\n\nYour password was reset successfully. If this wasn\'t you, contact your admin immediately.`,
  });

  return res.status(200).json({ ok: true });
}

module.exports = { login, changePassword, forgotPassword, resetPassword };
